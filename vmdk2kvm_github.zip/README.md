vmdk2kvm.py
   __ ___ ____ _ __ _ ____ _ _ _ _
  /__\ ( ) ( \/ )( ( \/ ___( \/ ( \/ )
 /(__)\ / _( ) ) D (\ \/ /) ) __/) / / \
(__)(__(____/ (____/\_)(_/(_/___(__/ (_/\_/)
Ultimate VMware VMDK → KVM/QEMU Conversion & Fix Tool.
============================================================
A production-grade powerhouse for seamless VMware to KVM migrations.
Handles everything: snapshots, fixes, conversions, tests, and more.
With safety nets, parallel processing, and daemon mode for automation.
This is a production-minded, "do it all" converter/fixer with:
- Multiple input sources: Seamlessly handle local VMDK files, fetch from remote ESXi hosts via SSH,
  extract and process OVA/OVF packages, or perform live fixes on running VMs through secure SSH connections.
- Snapshot chain handling: Automatically flatten complex snapshot chains into single, manageable images,
  with optional recursive fetching of parent descriptors for complete chain preservation.
- Filesystem and boot fixes: Intelligent rewriting of /etc/fstab to use stable identifiers like UUID (preferred),
  PARTUUID, LABEL, or PARTLABEL; btrfs subvolume sanity checks and canonicalization to eliminate virt-v2v warnings;
  GRUB root= parameter updates for reliable booting in the new environment.
- Windows best-effort support: Hooks for editing Boot Configuration Data (BCD) stores to ensure smooth
  transitions, including virtio driver injection for improved performance on KVM.
- LUKS crypttab handling: Rewrite crypttab entries to use stable identifiers, maintaining encrypted volume integrity.
- MDRAID (mdadm) checks: Verify and update mdadm configurations for software RAID setups.
- Conversion outputs: Flexible output formats including qcow2, raw, or VDI; built-in compression with customizable levels (1-9);
  resize hooks to expand or shrink disks as needed; post-conversion validation and SHA256 checksum generation for data integrity.
- Testing capabilities: Smoke tests via libvirt (define and start domains) and direct QEMU launches,
  supporting both UEFI and BIOS modes, with options for headless operation and domain persistence.
- Safety features: Dry-run mode for previewing changes without modifications; automatic backups of critical files like fstab;
  detailed Markdown reports with JSON-embedded data; rich progress bars for long operations; error recovery with checkpointing.
- Config support: YAML/JSON configurations with multi-file merging for overrides; keys match CLI arguments for easy translation.
- Support for multiple VMs: Process multiple virtual machines from a single config file, ideal for batch migrations.
- Daemon mode: Run as a systemd service, watching directories for new VMDK files and automatically processing them.
Design notes (based on your actual pain points):
- NEVER rely on /dev/disk/by-path for mounting inside libguestfs. It often doesn't exist in the appliance,
  so we use direct device mounting with fallback to brute-force detection.
- For fstab rewrite, we follow your bash semantics, but enhanced:
  - If spec is /dev/disk/by-path/*: resolve → map → UUID= preferred, else PARTUUID=, else LABEL=, else PARTLABEL=.
  - Additionally canonicalize "btrfsvol:" inspection hints to normal stable specs (fixes virt-v2v warnings).
  - For repeated by-path on same disk, we can infer /dev/sdaN or /dev/nvme0n1pN using the real root device.
- Initramfs regeneration is distro-aware and *safe*:
  - If dracut fails due to missing /lib/modules/<host-kernel>, retry with --kver inside guest if detectable,
    else fallback to --no-kernel + regenerate-all if available, else skip with loud warning.
- GRUB device.map warnings: remove stale device.map to prevent boot issues.
- Report generation: Markdown with JSON blocks for easy parsing and human-readable summaries.
Requires:
- python3
- qemu-img
- libguestfs-python (guestfs)
- optional: PyYAML, termcolor
- optional: virsh, qemu-system-*, rsync, sgdisk/parted
Install packages:
- sudo dnf install -y libguestfs-tools libguestfs qemu-img libvirt edk2-ovmf python3-pip python3-PyYAML python3-tqdm \
&& sudo python3 -m pip install --no-deps --ignore-installed rich termcolor watchdog
Usage:
  ./vmdk2kvm.py --help
  ./vmdk2kvm.py --config config.yaml local
  ./vmdk2kvm.py --config base.yaml --config overrides.yaml local
Config:
  YAML/JSON keys match argparse dest names (dash or underscore ok). Later configs override earlier.

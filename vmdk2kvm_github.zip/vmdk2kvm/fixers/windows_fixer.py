from __future__ import annotations

# Windows-related helpers are implemented inside OfflineFSFix; this module provides import surface.
from .offline_fixer import OfflineFSFix

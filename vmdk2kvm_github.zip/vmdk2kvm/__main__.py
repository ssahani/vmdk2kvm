from __future__ import annotations

import sys
from .cli.argument_parser import parse_args_with_config
from .orchestrator.magic_orchestrator import Magic
from .core.exceptions import Fatal

def main() -> None:
    args, _conf, logger = parse_args_with_config()
    try:
        rc = Magic(logger, args).run()
    except Fatal as e:
        logger.error(str(e))
        rc = e.code
    sys.exit(int(rc))

if __name__ == "__main__":
    main()
